import scrapy


class GloboSpider(scrapy.Spider):
    name = 'Globo'
    allowed_domains = ['globo.com']
    start_urls = ['http://www.globo.com/']

    def parse(self, response):
        pass
    for article in response.css("article"):
        link    = article.css("div.texts h2 a::attr(href)").extract_first()
        title   = article.css("div.texts h2 a::text").extract_first()
        author  = article.css("div.texts div.info a::text").extract_first()

        yield {'link': link, 'title': title, 'author': author}